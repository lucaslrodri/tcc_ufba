import beaglebone_pru_adc as adc
from flask import Flask, render_template, request, json
import thread
import time

class adc_:
    def __init__(self, numSamples_ = 10000, delayCapture_ = 0.1, delayADC_ = 0, oneTime_ = False):
        self.numSamples = numSamples_
        self.delayCapture = delayCapture_
        self.delayADC  = delayADC_
        self.oneTime = oneTime_
        print("ADC inicializado")
        print("Samples: ", self.numSamples, "Capture delay: ", self.delayCapture, "ADC speed: ", self.delayADC,"Loop: ", self.oneTime)
    def captureData(self):
        capture = adc.Capture()
        capture.oscilloscope_init(adc.OFF_VALUES, self.numSamples) # captures AIN0 - the first elt in AIN array
        capture.start()
        capture = adc.Capture()
        while(True):
            if capture.oscilloscope_is_complete():
                break
        capture.stop()
        capture.wait()
        self.captureSamples = capture.oscilloscope_data(self.numSamples)
        capture.close()
        
highSpeedADC = adc_(delayCapture_ = 2)
time.sleep(0.1)

def captureThread(current_adc):
    while(True):
        time.sleep(current_adc.delayCapture)
        print("Iniciando captura")
        current_adc.captureData()
    return

try:
    thread.start_new_thread(captureThread,(highSpeedADC,))
except:
    print("Erro ao iniciar a captura de dados, renicie o programa.")
app = Flask(__name__)

@app.route('/')
def toolbox():
    return render_template('toolbox.html')
    
if __name__ == '__main__':
    app.run('0.0.0.0')